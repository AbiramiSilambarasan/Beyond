package com.beyond.server.beyondserverservice.resource;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import com.beyond.server.beyondserverservice.model.SetofDatas;

public class ServerFetchDatasTest{

	@Test
	public void testAddMacDatas() throws Exception {
		ServerFetchDatas serverDatas=new ServerFetchDatas();
		
		List<SetofDatas> listDatas=new ArrayList<SetofDatas>();
		SetofDatas datas = new SetofDatas();
		datas.setId(8);
		datas.setIpAddress("3.4.5.6");
		listDatas.add(datas);
		
		assertEquals(true, serverDatas.addMacDatas(listDatas));
	}
}
