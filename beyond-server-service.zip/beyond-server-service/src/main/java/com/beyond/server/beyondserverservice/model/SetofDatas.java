package com.beyond.server.beyondserverservice.model;

public class SetofDatas {

	public int id;
	public String ipAddress;
	
	public SetofDatas() {
	}
	public SetofDatas(int id, String ipAddress) {
		this.id = id;
		this.ipAddress = ipAddress;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	
}
