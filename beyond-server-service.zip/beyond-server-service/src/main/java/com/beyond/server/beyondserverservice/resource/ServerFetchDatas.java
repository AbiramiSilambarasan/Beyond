package com.beyond.server.beyondserverservice.resource;



import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.beyond.server.beyondserverservice.model.SetofDatas;

@RestController
@RequestMapping("/server")
public class ServerFetchDatas {

	@Autowired
	private JdbcTemplate jdbcTmplte;

	
	@RequestMapping("/getSetOfDatas")
	public List<SetofDatas> getDatasFromDB(){
		System.out.println("getting datas from db");
		//List<SetofDatas> list1=Arrays.asList(new SetofDatas(0,"1.0.0.2"));
		
		String sql = "Select * from beyond.machinedatas";
		ArrayList<SetofDatas> creditCrdEntys = new ArrayList<SetofDatas>();

		List<java.util.Map<String, Object>> lists = getJdbcTemplate().queryForList(sql);
		System.out.println("getting datas from db11");
		for (java.util.Map<String, Object> list : lists) {
			SetofDatas creditCrdEnty = new SetofDatas();
			creditCrdEnty.setId((int) list.get("id"));
			creditCrdEnty.setIpAddress((String) list.get("ipAddress"));
			creditCrdEntys.add(creditCrdEnty);
		}
		System.out.println("getting datas from db22");
		return creditCrdEntys;
	}

private JdbcTemplate getJdbcTemplate() {
	// TODO Auto-generated method stub
	return jdbcTmplte;
}

@RequestMapping("/addSetofDatas")
public String addMacDatas(@RequestBody List<SetofDatas> machineDatas){
	// TODO Auto-generated method stub
	String status = "Values successfully added";
	String sql = "INSERT INTO beyond.machinedatas(id,ipAddress) values (?,?)";
	System.out.println("query : "+machineDatas.size());
	try{
	getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
		@Override
		public void setValues(PreparedStatement ps, int i) throws SQLException {
			System.out.println("query : "+i);
			SetofDatas machineData = machineDatas.get(i);
			System.out.println("query : "+machineData.getIpAddress());
			ps.setInt(1, machineData.getId());
			ps.setString(2, machineData.getIpAddress());
		}		
		@Override
		public int getBatchSize() {
			return machineDatas.size();
		}
		 });
	status="Values successfully added";
	}catch(Exception e){
		status="Exception in adding of datas "+e;
		System.out.println("Exception in add values : "+e);
	}
	return status;
}

}
